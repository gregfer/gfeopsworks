default['zypper']['smt_host'] = nil
